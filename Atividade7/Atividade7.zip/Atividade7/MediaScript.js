var nota1 = parseFloat(prompt("Digite sua primeira nota:"));

var nota2 = parseFloat(prompt("Digite sua segunda nota:"));

var nota3 = parseFloat(prompt("Digite sua terceira nota:"));

var media = parseFloat((nota1 + nota2 + nota3)/3);

alert("Média " + media);